# src/bmp_lib/__init__.py
from .bmp_func import get_BMP_Article_Object
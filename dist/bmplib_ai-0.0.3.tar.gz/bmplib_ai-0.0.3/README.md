This package implement all the logic of Brief My Press.AI.

To install, tap:

`pip install BmpLib-Ai`


[GitHub](https://github.com/Taoufiq-Ouedraogo/Brief-My-Press-AI-Library)



[Tuto on how to publish python package](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

For each version of the package:
- python3 -m build

- twine upload dist/*




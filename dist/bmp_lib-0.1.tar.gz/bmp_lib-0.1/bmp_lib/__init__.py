# Create an environment
# python -m venv .venv


# Windows PowerShell
# .venv\Scripts\Activate.ps1

# macOS and Linux
# source .venv/bin/activate

# deactivate the env 
# deactivate

#pip install streamlit


# streamlit hello or python -m streamlit hello
# streamlit run API/Main_App.py


# pip install -r requirements.txt
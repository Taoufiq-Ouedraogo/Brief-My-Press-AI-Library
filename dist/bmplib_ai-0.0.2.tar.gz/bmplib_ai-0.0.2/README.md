This package implement all the logic of Brief My Press.AI.

To install, tap:

`pip install bmp-lib`


[GitHub](https://github.com/Taoufiq-Ouedraogo/Brief-My-Press-AI-Library)



[Tuto on how to publish python package](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

Some steps:
- python3 -m build

- python3 -m twine upload --repository testpypi dist/*

- puis pour update : twine upload dist/*




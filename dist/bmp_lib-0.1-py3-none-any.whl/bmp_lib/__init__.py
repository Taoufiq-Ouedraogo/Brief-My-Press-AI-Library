from .bmp_func import bmp_summaries_and_audio



# Build the package
# python setup.py sdist bdist_wheel

# Install package locally
# pip install -e .

# git tag 0.0.1 -m "New Release"
# git push origin 0.0.1


 